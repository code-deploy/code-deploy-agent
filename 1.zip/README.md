# CodeDeployAgent
Deploy-agent is agent of Automated deployments tools


# RoadMap

- [ ] Config
- [x] 支持多种触发器
	- [x] http
	- [ ] sqs
	- [ ] aliyun
- [ ] Runner
	- [ ] Task State Machine
	- [ ] parse deploy.yml
	- [ ] plugins
