#!/bin/sh

touch INSTALL
echo 'Install Success';
